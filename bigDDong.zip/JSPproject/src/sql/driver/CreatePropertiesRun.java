package sql.driver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class CreatePropertiesRun {

	public static void main(String[] args) {
		
		Properties prop = new Properties();
		
		prop.setProperty("url",	"jdbc:oracle:thin:@khacademyDB_high?TNS_ADMIN=/Users/chohanwool/dev/Wallet_khacademyDB");
		prop.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		prop.setProperty("user", "SERVER");
		prop.setProperty("PWD", "Academy1111!!");
		
		try {
			prop.store(new FileOutputStream("./src/sql/driver/driver.properties"), "driver.properties");
			prop.storeToXML(new FileOutputStream("./src/sql/member/member-mapper.xml"), "member-mapper.xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
