package com.kh.member.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;

import oracle.security.o3logon.a;

/**
 * Servlet implementation class InsertMemberController
 */
@WebServlet("/insert2.me")
public class InsertMemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertMemberController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 요청방식 = POST
		// 1) 인코딩
		request.setCharacterEncoding("UTF-8");
		
		// 2) 값 뽑기
		String userId = request.getParameter("userId");
		String userPwd = request.getParameter("userPwd");
		String userName = request.getParameter("userName");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String[] interestArr = request.getParameterValues("interest");
		
		// 잘 들어오나 확인
		//System.out.println(userId);
		//System.out.println(userPwd);
		//System.out.println(userName);
		//System.out.println(email);
		//System.out.println(phone);
		//System.out.println(address);
		
		// System.out.println(interestArr);
		// 배열은 주소값이 나옴
		// String.join(); 을 사용해서 문자열로 변환
		// 사용자가 체크를 하나도 안 할 수도 있으니 조건문을 추가
		String interest = "";
		
		if(interestArr != null) {
			interest = String.join(",", interestArr);			
		}
		// 만약 사용자가 선택을 하지 않아 null 값이 null 일 경우 빈 문자열이 나옴 
		
		//System.out.println(interest);
		
		// 3) 값 가공처리
		Member m = new Member(userId,userPwd,userName,email,phone,address, interest);
	
		// 4) Service단으로 넘겨주고 결과받아 오기
		int result = new MemberService().insertMember(m);
		
		// 5) 결과에 따른 응답뷰 지정
		if (result > 0) { // success
			request.getSession().setAttribute("alertMsg", "회원가입 성공!");
			response.sendRedirect(request.getContextPath());
		} else { // fail
			request.setAttribute("errorMsg", "회원가입 실패");
			request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
