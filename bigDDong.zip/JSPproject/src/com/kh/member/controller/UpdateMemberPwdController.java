package com.kh.member.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;

/**
 * Servlet implementation class UpdateMemberPwdController
 */
@WebServlet("/updatePwd.me")
public class UpdateMemberPwdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMemberPwdController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// POST 방식으로 받기떄문에 인코딩
		request.setCharacterEncoding("UTF-8");
		
		// 값 뽑기
		String curPwd = request.getParameter("curPwd");
		String newPwd = request.getParameter("newPwd");
		String userId = request.getParameter("userId");
		
		// 가공 생략
		
		// Service단으로 토스후 결과 받기
		Member m = new MemberService().updatePwd(userId, newPwd, curPwd);
		System.out.println(m);
		// 응답뷰 지정
		if (m != null) { // success
			
			HttpSession session = request.getSession();
			
			session.setAttribute("loginUser", m);
			session.setAttribute("alertMsg", "비밀번호 변경 성공!");
			response.sendRedirect(request.getContextPath() + "/myPage.me");
			
		} else { // fail
			request.setAttribute("errorMsg", "비밀번호 변경 실패");
			request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
