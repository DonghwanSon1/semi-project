package com.kh.member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/login.me")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*
		 * HttpServletRequest, HttpServletResponse 객체
		 * 
		 * - request  : 서버로 요청할때의 정보들이 담겨있음(요청시 전달값, 요청 전송방식등..)
		 * - response : 요청에 대해 응답하고자 할 때 사용하는 객
		 */
		
		// 1) POST방식의 경우 인코딩 설정 해줘야 한다
		request.setCharacterEncoding("UTF-8");
		
		// 2) 요청이 들어올때 전달된 값들을 꺼내 변수에 담아 준다
		String userId = request.getParameter("userId");
		String userPwd = request.getParameter("userPwd");
		
		// 3) Service Class 호출하면서 값 전달
		Member loginUser = new MemberService().loginMember(userId, userPwd);
		// 반환된 결과 로그인된 멤버의 정보 => Member VO객체로 받아줌
		
		// 4) 결과에 따른 응답뷰 지정
		
		// 로그인 성공 or 실패?
		if (loginUser == null) {// 로그인 실패시 => errorPage 응답
			
			request.setAttribute("errorMsg", "로그인에 실패했습니다.");
			
			RequestDispatcher view = request.getRequestDispatcher("views/common/errorPage.jsp");
			
			view.forward(request, response);
		} else { // 로그인 성공 => index.jsp페이지 응답
			
			HttpSession session = request.getSession();
			
			session.setAttribute("loginUser", loginUser);
			
			// 로그인 성공시 alert창 띄우기
			session.setAttribute("alertMsg", "로그인 성공");
			
			// 기존의 포워딩 방식
//			RequestDispatcher view = request.getRequestDispatcher("index.jsp");
//			
//			view.forward(request, response);
			
//			response.sendRedirect("/jsp");
			response.sendRedirect(request.getContextPath());
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
